import random
from bubbleSort import *

def main():

    List = random.sample(range(1,100),20)
    print('List belum terurut:', List)
    if ganjil(List[0]) == True:
        List = insertionSortA(List)
    else:
        List = insertionSortD(List)

    print('List terutut:', List)

    i = 1
    while i <=5:
        print('Masukkan angka ke-', i, ':', end=' ')
        el = int(input())
        List.append(el)
        i += 1
    print('List baru:', List)

    List2 = []
    if ganjil(List[len(List)-1]) == True:
        for i in List:
            List2.append(i*3)
        print('List 2 belum terutut= ', List2)
        List2 = selectionsortA(List2)
    else:
        for i in List:
            List2.append(i*2)
        print('List 2 belum terutut= ', List2)
        List2 = selectionsortD(List2)
    print('List 2 terutut= ', List2)



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()


