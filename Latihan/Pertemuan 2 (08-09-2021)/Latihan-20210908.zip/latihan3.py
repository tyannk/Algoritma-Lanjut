# Mangga 150000 untuk 5kg +
# dijual keuntungan 10%
# anna beli 3kg harganya?

semuamangga = 150000
sekilo = semuamangga/5
jualsekilo = sekilo + (sekilo*10/100)
beli = 3 * jualsekilo
print('Anna bayar = ', beli)

hargajualsemua = semuamangga + (semuamangga*10/100)
hargajualsekilo = hargajualsemua/5
annabeli = hargajualsekilo * 3
print('Anna bayar = ', annabeli)