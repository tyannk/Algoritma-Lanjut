a = 50.0
b = 5.5
print(a)
print(b)
a = a/5
b = b - 0.5
print('nilai a kedua', a)
print("nilai b kedua", b)
a = b / a
b = b - a
print('nilai a ketiga', a)
print('nilai b ketiga', b)