import random

# fungsi bilangan acak diambil antara angka awal dan angka akhir, sebanyak jumlah

def acak(awal,akhir,jumlah):
    L = random.sample(range(awal,akhir+1),jumlah)
    return L

# fungsi pembuatan list baru dari listawal dengan hanya beranggotakan angka-angka ganjil

def ganjil(listawal):
    listganjil = []
    for i in listawal:
        if (i%2 != 0):
            listganjil.append(i)

    return listganjil

# fungsi pembuatan list baru dari listawal dengan hanya beranggotakan angka-angka genap

def genap(listawal):
    listgenap = []
    for i in listawal:
        if(i%2 == 0):
            listgenap.append(i)

    return listgenap

# fungsi merubah setiap elemen dalam list darilist dari tipe data integer ke string

def jadistring(darilist):
    liststr = []
    for i in darilist:
        liststr.append(str(i))

    return liststr