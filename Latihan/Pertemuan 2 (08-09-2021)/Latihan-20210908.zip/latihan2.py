x = 5
y = 2
print((4*x) + (5*y))