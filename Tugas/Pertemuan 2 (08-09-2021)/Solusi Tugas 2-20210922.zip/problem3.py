# gaji = 3500000
# tunjangan 30% gaji
# pajak 10% seluruh penghasilan
# gaji bersih?

gaji = 3500000
persentunjangan = 30/100
persenpajak = 10/100

tunjangan = gaji * persentunjangan
pajak = (gaji + tunjangan) * persenpajak
gajibersih = gaji + tunjangan - pajak

print('Gaji Bersih = Rp.', gajibersih)