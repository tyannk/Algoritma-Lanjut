# kecepatan awal 70km/jam
# waktu 30 menit
# kecepatan akhir 100km/jam
# vt = v0 + a*t

v0 = 70 #km/jam
t = 30/60 # jam
vt = 100 #km/jam
a = (vt - v0) / t
print('Percepatan = ', a)