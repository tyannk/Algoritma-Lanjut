a = 5
b = 2
print('Nilai a pertama :' + str(a))
print('Nilai b pertama :' + str(b))
a = b # a=2
b += a # b = b + a  -> b = 2 + 2 = 4
print('Nilai a kedua : ' + str(a))
print('Nilai b kedua : ' + str(b))
a = b + 2 # a = 4 + 2 = 6
print(type(a))
print('sebelum', type(b))
b = a / 2 # b = 6 / 2 = 3
print('setelah', type(b))
print('Nilai a ketiga : ' , a)
print('Nilai b ketiga : ' , int(b))