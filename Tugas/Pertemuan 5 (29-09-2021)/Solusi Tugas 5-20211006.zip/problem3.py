from bubbleSort import *

ListBarang = [[21,'Sampo',43000], [18,'Sabun',28000],
[9,'Detergent',21000], [2,'Pasta Gigi',18000],
[6,'Sikat Gigi',12000],[24,'Tissue',8000],
[5,'Handuk',78000],[15,'Gayung',17500],
[28,'Conditioner',31000],[1,'Sabun Tangan',19000]]

print('Urutkan berdasarkan:')
print('1. id terkecil ke terbesar')
print('2. id terbesar ke terkecil')
print('3. Nama barang a ke z')
print('4. Nama barang z ke a')
print('5. Harga barang termurah ke termahal')
print('6. Harga barang termahal ke termurah')
print('Masukkan pilihan:', end=' ')
pilih = input()

if pilih == '1':
    ListBarang = mergeSortA(ListBarang, 0)
elif pilih == '2':
    ListBarang = mergeSortD(ListBarang,0)
elif pilih == '3':
    ListBarang = mergeSortA(ListBarang,1)
elif pilih == '4':
    ListBarang = mergeSortD(ListBarang,1)
elif pilih == '5':
    ListBarang = mergeSortA(ListBarang, 2)
elif pilih == '6':
    ListBarang = mergeSortD(ListBarang, 2)
else:
    print('Pilihan tidak valid')

print('ID\t\t NAMA BARANG \t\t HARGA')
for i in range(len(ListBarang)):
    print(ListBarang[i][0],'\t\t' ,ListBarang[i][1], '\t\t' ,ListBarang[i][2])