from buatlist import *

# list acak dari 1 sampai 100 sebanyak 10 angka
List1 = acak(1,10,5)
print('List 1: ',List1)

# list acak dari 400 sampai 500 sebanyak 20 angka
List2 = acak(20,40,7)
print('List 2: ',List2)

# penggabungan list1 dan list disimpan di list3
List3 = List1 + List2
print('List 3: ',List3)


# list bilangan ganjil dari list3 urut dari kecil ke besar
Ganjil = ganjil(List3)
Ganjil.sort()
print('Ganjil dari List3: ',Ganjil)


# list bilangan genap dari list3 urut dari besar ke kecil
Genap = genap(List3)
Genap.sort()
Genap.reverse()
print('Genap dari List3: ', Genap)

# Konversi jadi string
Liststr = jadistring(Genap)
print('List string = ', Liststr)
print('String dari Genap',''.join(Liststr))
