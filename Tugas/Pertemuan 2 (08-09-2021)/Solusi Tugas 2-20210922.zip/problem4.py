# 86kg beras
# dikemas dlm 1/4 jumlah plastik miliknya
# 1 plastik 6kg
# sisa beras 2kg
# jumlah plastik seluruh?

beras = 86
plastikterbagi = 4
perplastik = 6
sisaberas = 2

berasterbungkus = beras - sisaberas
plastikterpakai = berasterbungkus/perplastik
seluruhplastik = plastikterpakai * plastikterbagi
print('Jumlah seluruh plastik= ', int(seluruhplastik))

