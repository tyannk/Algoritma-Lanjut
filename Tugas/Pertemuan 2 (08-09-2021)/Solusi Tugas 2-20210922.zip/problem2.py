# 4l -> 40km
# terisi 25l
# menempuh 100km
# sisa bensin

vol = 4
jarak = 40

vol0 = 25
jarak1 = 100

perliter = jarak/vol
print('jarak yang dapat ditempuh dengan 1 liter bensin= ', perliter, 'km')
vol1 = vol0 - (jarak1/perliter)

print('sisa bensin= ', vol1, 'liter')